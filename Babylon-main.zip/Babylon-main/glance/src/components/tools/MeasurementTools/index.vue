<template
  src="paraview-glance/src/components/tools/MeasurementTools/template.html"
/>
<style
  module
  src="paraview-glance/src/components/tools/MeasurementTools/style.css"
/>
<script src="paraview-glance/src/components/tools/MeasurementTools/script.js" />
