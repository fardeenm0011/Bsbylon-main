<template src="paraview-glance/src/components/tools/CropTool/template.html" />
<style module src="paraview-glance/src/components/tools/CropTool/style.css" />
<script src="paraview-glance/src/components/tools/CropTool/script.js" />
