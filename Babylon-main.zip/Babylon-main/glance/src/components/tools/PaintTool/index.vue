<template src="paraview-glance/src/components/tools/PaintTool/template.html" />
<style module src="paraview-glance/src/components/tools/PaintTool/style.css" />
<script src="paraview-glance/src/components/tools/PaintTool/script.js" />
