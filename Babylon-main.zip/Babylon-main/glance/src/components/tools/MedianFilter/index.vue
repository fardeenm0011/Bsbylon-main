<template
  src="paraview-glance/src/components/tools/MedianFilter/template.html"
/>
<style
  module
  src="paraview-glance/src/components/tools/MedianFilter/style.css"
/>
<script src="paraview-glance/src/components/tools/MedianFilter/script.js" />
