<template
  src="paraview-glance/src/components/controls/Representation/template.html"
/>
<style module src="paraview-glance/src/components/core/Datasets/controls.css" />
<script src="paraview-glance/src/components/controls/Representation/script.js" />
