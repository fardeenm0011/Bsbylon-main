export default {
  name: 'MoleculeInformation',
  props: ['dataset'],
};
