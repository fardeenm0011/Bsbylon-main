<template
  src="paraview-glance/src/components/controls/Information/FieldData/template.html"
/>
<style module src="paraview-glance/src/components/core/Datasets/controls.css" />
<script src="paraview-glance/src/components/controls/Information/FieldData/script.js" />
