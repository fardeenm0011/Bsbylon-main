<template
  src="paraview-glance/src/components/controls/Information/MatrixView/template.html"
/>
<style module src="paraview-glance/src/components/core/Datasets/style.css" />
<script src="paraview-glance/src/components/controls/Information/MatrixView/script.js" />
