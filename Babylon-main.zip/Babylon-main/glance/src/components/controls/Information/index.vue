<template
  src="paraview-glance/src/components/controls/Information/template.html"
/>
<style module src="paraview-glance/src/components/core/Datasets/style.css" />
<script src="paraview-glance/src/components/controls/Information/script.js" />
