<template
  src="paraview-glance/src/components/widgets/TreeView/Node/template.html"
/>
<style module src="paraview-glance/src/components/widgets/TreeView/style.css" />
<script src="paraview-glance/src/components/widgets/TreeView/Node/script.js" />
