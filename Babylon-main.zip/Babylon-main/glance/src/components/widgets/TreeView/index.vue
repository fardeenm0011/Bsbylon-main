<template src="paraview-glance/src/components/widgets/TreeView/template.html" />
<style module src="paraview-glance/src/components/widgets/TreeView/style.css" />
<script src="paraview-glance/src/components/widgets/TreeView/script.js" />
