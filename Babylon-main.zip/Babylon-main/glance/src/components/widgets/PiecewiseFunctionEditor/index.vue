<template
  src="paraview-glance/src/components/widgets/PiecewiseFunctionEditor/template.html"
/>
<style
  module
  src="paraview-glance/src/components/widgets/PiecewiseFunctionEditor/style.css"
/>
<script src="paraview-glance/src/components/widgets/PiecewiseFunctionEditor/script.js" />
