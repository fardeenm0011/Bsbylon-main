<template src="paraview-glance/src/components/widgets/PopUp/template.html" />
<style module src="paraview-glance/src/components/widgets/PopUp/style.css" />
<script src="paraview-glance/src/components/widgets/PopUp/script.js" />
