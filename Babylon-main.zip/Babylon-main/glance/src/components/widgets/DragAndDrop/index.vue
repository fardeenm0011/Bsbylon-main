<template
  src="paraview-glance/src/components/widgets/DragAndDrop/template.html"
/>
<style />
<script src="paraview-glance/src/components/widgets/DragAndDrop/script.js" />
