<template
  src="paraview-glance/src/components/widgets/ColorGroup/template.html"
/>
<style
  module
  src="paraview-glance/src/components/widgets/ColorGroup/style.css"
/>
<script src="paraview-glance/src/components/widgets/ColorGroup/script.js" />
