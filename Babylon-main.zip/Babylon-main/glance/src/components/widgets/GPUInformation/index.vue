<template
  src="paraview-glance/src/components/widgets/GPUInformation/template.html"
/>
<style
  module
  src="paraview-glance/src/components/widgets/GPUInformation/style.css"
/>
<script src="paraview-glance/src/components/widgets/GPUInformation/script.js" />
