<template
  src="paraview-glance/src/components/widgets/PalettePicker/template.html"
/>
<style
  module
  src="paraview-glance/src/components/widgets/PalettePicker/style.css"
/>
<script src="paraview-glance/src/components/widgets/PalettePicker/script.js" />
