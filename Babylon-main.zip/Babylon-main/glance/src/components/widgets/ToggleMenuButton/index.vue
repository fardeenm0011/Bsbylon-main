<template src="paraview-glance/src/components/widgets/ToggleMenuButton/template.html" />
<style module src="paraview-glance/src/components/widgets/ToggleMenuButton/style.css" />
<script src="paraview-glance/src/components/widgets/ToggleMenuButton/script.js" />
