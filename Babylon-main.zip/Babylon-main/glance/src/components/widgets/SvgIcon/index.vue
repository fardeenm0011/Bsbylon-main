<template src="paraview-glance/src/components/widgets/SvgIcon/template.html" />
<script src="paraview-glance/src/components/widgets/SvgIcon/script.js" />
