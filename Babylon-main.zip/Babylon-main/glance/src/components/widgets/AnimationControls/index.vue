<template
  src="paraview-glance/src/components/widgets/AnimationControls/template.html"
/>
<style
  module
  src="paraview-glance/src/components/widgets/AnimationControls/style.css"
/>
<script src="paraview-glance/src/components/widgets/AnimationControls/script.js" />
