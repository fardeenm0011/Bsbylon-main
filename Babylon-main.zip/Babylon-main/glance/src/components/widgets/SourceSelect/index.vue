<template
  src="paraview-glance/src/components/widgets/SourceSelect/template.html"
/>
<script src="paraview-glance/src/components/widgets/SourceSelect/script.js" />
