<template
  src="paraview-glance/src/components/widgets/CollapsibleToolbar/Item/template.html"
/>
<script src="paraview-glance/src/components/widgets/CollapsibleToolbar/Item/script.js" />
