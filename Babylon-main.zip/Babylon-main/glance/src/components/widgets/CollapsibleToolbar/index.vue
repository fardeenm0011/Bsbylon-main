<template
  src="paraview-glance/src/components/widgets/CollapsibleToolbar/template.html"
/>
<script src="paraview-glance/src/components/widgets/CollapsibleToolbar/script.js" />
