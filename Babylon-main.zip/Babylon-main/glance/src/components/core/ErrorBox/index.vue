<template src="paraview-glance/src/components/core/ErrorBox/template.html" />
<style module src="paraview-glance/src/components/core/ErrorBox/style.css" />
<script src="paraview-glance/src/components/core/ErrorBox/script.js" />
