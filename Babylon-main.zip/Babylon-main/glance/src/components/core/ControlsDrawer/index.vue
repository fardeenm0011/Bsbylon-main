<template
  src="paraview-glance/src/components/core/ControlsDrawer/template.html"
/>
<script src="paraview-glance/src/components/core/ControlsDrawer/script.js" />
<style
  module
  src="paraview-glance/src/components/core/ControlsDrawer/style.css"
/>
