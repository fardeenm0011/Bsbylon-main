<template src="paraview-glance/src/components/core/FileLoader/template.html" />
<style module src="paraview-glance/src/components/core/FileLoader/style.css" />
<script src="paraview-glance/src/components/core/FileLoader/script.js" />
