<template src="paraview-glance/src/components/core/Datasets/template.html" />
<style module src="paraview-glance/src/components/core/Datasets/style.css" />
<script src="paraview-glance/src/components/core/Datasets/script.js" />
