<template src="paraview-glance/src/components/core/LayoutView/template.html" />
<style module src="paraview-glance/src/components/core/LayoutView/style.css" />
<script src="paraview-glance/src/components/core/LayoutView/script.js" />
