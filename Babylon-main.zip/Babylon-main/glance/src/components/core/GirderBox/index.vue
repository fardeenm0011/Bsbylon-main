<template src="paraview-glance/src/components/core/GirderBox/template.html" />
<style module src="paraview-glance/src/components/core/GirderBox/style.css" />
<script src="paraview-glance/src/components/core/GirderBox/script.js" />
