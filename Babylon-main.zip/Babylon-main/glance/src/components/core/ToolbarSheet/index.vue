<template
  src="paraview-glance/src/components/core/ToolbarSheet/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/ToolbarSheet/style.css"
/>
<script src="paraview-glance/src/components/core/ToolbarSheet/script.js" />
