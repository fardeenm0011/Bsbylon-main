<template
  src="paraview-glance/src/components/core/StateFileGenerator/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/StateFileGenerator/style.css"
/>
<script src="paraview-glance/src/components/core/StateFileGenerator/script.js" />
