<template
  src="paraview-glance/src/components/core/GlobalSettings/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/GlobalSettings/style.css"
/>
<script src="paraview-glance/src/components/core/GlobalSettings/script.js" />
