<template
  src="paraview-glance/src/components/core/BrowserIssues/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/BrowserIssues/style.css"
/>
<script src="paraview-glance/src/components/core/BrowserIssues/script.js" />
