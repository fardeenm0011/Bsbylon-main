<template src="paraview-glance/src/components/core/AboutBox/template.html" />
<style module src="paraview-glance/src/components/core/AboutBox/style.css" />
<script src="paraview-glance/src/components/core/AboutBox/script.js" />
