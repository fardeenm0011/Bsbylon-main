<template src="paraview-glance/src/components/core/Landing/template.html" />
<style module src="paraview-glance/src/components/core/Landing/style.css" />
<script src="paraview-glance/src/components/core/Landing/script.js" />
