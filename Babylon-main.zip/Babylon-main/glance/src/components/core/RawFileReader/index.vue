<template
  src="paraview-glance/src/components/core/RawFileReader/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/RawFileReader/style.css"
/>
<script src="paraview-glance/src/components/core/RawFileReader/script.js" />
