<template
  src="paraview-glance/src/components/core/Screenshots/ScreenshotDialog/template.html"
/>
<style
  module
  src="paraview-glance/src/components/core/Screenshots/ScreenshotDialog/style.css"
/>
<script src="paraview-glance/src/components/core/Screenshots/ScreenshotDialog/script.js" />
