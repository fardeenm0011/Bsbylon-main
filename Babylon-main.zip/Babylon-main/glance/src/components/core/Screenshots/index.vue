<template src="paraview-glance/src/components/core/Screenshots/template.html" />
<style module src="paraview-glance/src/components/core/Screenshots/style.css" />
<script src="paraview-glance/src/components/core/Screenshots/script.js" />
