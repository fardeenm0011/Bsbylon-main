<template src="paraview-glance/src/components/core/VtkView/template.html" />
<style module src="paraview-glance/src/components/core/VtkView/style.css" />
<script src="paraview-glance/src/components/core/VtkView/script.js" />
