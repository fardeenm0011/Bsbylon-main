<template src="paraview-glance/src/components/core/App/template.html" />
<style module src="paraview-glance/src/components/core/App/style.css" />
<script src="paraview-glance/src/components/core/App/script.js" />
