<template src="paraview-glance/src/components/core/EditTools/template.html" />
<style module src="paraview-glance/src/components/core/EditTools/style.css" />
<script src="paraview-glance/src/components/core/EditTools/script.js" />
