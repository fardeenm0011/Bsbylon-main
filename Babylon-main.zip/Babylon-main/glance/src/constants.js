export const Breakpoints = {
  // an alternative medium screen size
  md: 768,
};

export const Widgets = {
  CROP: 'CROP',
};

export default {
  Breakpoints,
  Widgets,
};
