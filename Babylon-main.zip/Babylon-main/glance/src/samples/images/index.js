import Aneurism from './aneurism.jpg';
import CAD from './cad.jpg';
import Engine from './engine.jpg';
import F1 from './F1.jpg';
// import Head from './head.jpg';
import Lidar from './Lidar.jpg';
import Lysozyme from './lysozyme.jpg';
import SinglePin from './singlepin.jpg';
import Tooth from './tooth.jpg';
import Covid19 from './covid19.jpg';

export default {
  Aneurism,
  CAD,
  Engine,
  F1,
  // Head,
  Lidar,
  Lysozyme,
  SinglePin,
  Tooth,
  Covid19,
};
