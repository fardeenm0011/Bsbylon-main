import Proxy from 'paraview-glance/src/config/proxy';

export default {
  Proxy,
};
