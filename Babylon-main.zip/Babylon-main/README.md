Clone and run:

```
npm install
npm start
```
