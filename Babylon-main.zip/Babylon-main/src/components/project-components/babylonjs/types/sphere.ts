type Sphere = {
  diameter: number;
  diameterX: number;
  diameterY: number;
  diameterZ: number;
};

export default Sphere;
