type Distance = {
  //number: number,
  x: {
    min: number;
    max: number;
  };
  y: {
    min: number;
    max: number;
  };
  z: {
    min: number;
    max: number;
  };
};

export default Distance;
