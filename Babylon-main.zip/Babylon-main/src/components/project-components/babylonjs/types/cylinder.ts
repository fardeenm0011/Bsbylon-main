type Cylinder = {
  diameter: number;
  topDiameter: number;
  bottomDiameter: number;
  height: number;
  tessellation: number;
  subidivisions: number;
};

export default Cylinder;
