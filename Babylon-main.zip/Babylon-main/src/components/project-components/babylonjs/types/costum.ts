type Costum = {
  height: number;
  width: number;
  length: number;
};

export default Costum;
