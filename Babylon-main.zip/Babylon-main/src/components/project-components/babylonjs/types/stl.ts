type Stl = {
  filename: string;
  file: string;
};

export default Stl;
