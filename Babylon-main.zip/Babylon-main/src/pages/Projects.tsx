import { useEffect, useState, useRef } from "react";
import MyIcon from "assets/MyIcons";
import NewProjectModal from "components/Modals/NewProject";
import DeleteProjectModal from "components/Modals/DeleteProject";
import { Auth, Storage } from "aws-amplify";
import { useNavigate } from "react-router-dom";
import {
  selectEmail,
  selectUserPlan,
  selectUsername,
} from "state/reducers/authSlice";
import { useAppSelector } from "state/hooks";
import api from "services/api";
import {
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import moment from "moment";
import { Tooltip } from "react-tooltip";

function Projects() {
  const [newProjectModalVisible, setNewProjectModalVisible] = useState(false);
  const [deleteProjectModalVisible, setDeleteProjectModalVisible] =
    useState(false);
  const [projectIdToDelete, setProjectIdToDelete] = useState<any>(null);
  const [projectNameToDelete, setProjectNameToDelete] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isQuerying, setIsQuerying] = useState(true);
  const [projects, setProjects] = useState<Array<any>>([]);
  const [page, setPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [openMobileMenu, setOpenMobileMenu] = useState(false);
  const [filteredProjects, setFilteredProjects] = useState<Array<any>>([]);
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [statusFilters, setStatusFilters] = useState<Array<string>>([
    "Idle",
    "Running",
    "Completed",
    "Terminated",
  ]);

  const [tableRows, setTableRows] = useState(4);

  const tableRef = useRef<HTMLTableElement>(null);
  const tableHeadRef = useRef<HTMLTableElement>(null);
  const tablePaginationRef = useRef<HTMLDivElement>(null);

  const toggleFilter = (status: string) => {
    if (statusFilters.includes(status)) {
      setStatusFilters((prev) => prev.filter((s) => s !== status));
    } else {
      setStatusFilters((prev) => [...prev, status]);
    }
  };

  const createNewProject = () => {
    setNewProjectModalVisible(true);
  };

  const navigate = useNavigate();
  const email = useAppSelector(selectEmail);
  const userPlan = useAppSelector(selectUserPlan);
  const userName = useAppSelector(selectUsername);

  useEffect(() => {
    const tableHeight = tableRef.current?.clientHeight;
    const tableHeadHeight = tableHeadRef.current?.clientHeight;
    const tablePaginationHeight = tablePaginationRef.current?.clientHeight;
    const tableRowHeight = document.getElementById("table-row")?.clientHeight;

    if (
      tableHeight &&
      tableHeadHeight &&
      tablePaginationHeight &&
      tableRowHeight
    ) {
      const rows = Math.floor(
        (tableHeight - tableHeadHeight - tablePaginationHeight) /
          (tableRowHeight + 5) -
          1
      );
      setTableRows(rows > 4 ? rows : 4);
    }
  }, [filteredProjects, tableRef, tableHeadRef, tablePaginationRef, tableRows]);

  useEffect(() => {
    try {
      Storage.list(`${userName}/projects/`, { pageSize: 1000 }).then(
        async (data) => {
          let projectData: any[] = [];
          const { results } = data;
          const projects: any[] = [];
          results.forEach((result) => {
            if (result.key?.includes("info.json")) {
              projects.push(result);
            }
          });
          const promises = projects.map(async (project) => {
            let info: any = {};
            const infoData = await Storage.get(project.key, {
              download: true,
              cacheControl: "no-cache",
            });
            if (infoData.Body) {
              const dataBody: any = infoData.Body;
              const dataString = await dataBody.text();
              const json = JSON.parse(dataString);
              info = json;
            }
            const projectData = {
              id: project.key.split("/").at(-2),
              lastModified: project.lastModified,
              ...info,
            };
            return projectData;
          });
          projectData = await Promise.all(promises);

          projectData.sort(
            (a, b) =>
              new Date(b.lastModified).getTime() -
              new Date(a.lastModified).getTime()
          );

          setProjects(projectData);
          setIsQuerying(false);
        }
      );
    } catch (e) {
      console.log(e);
    }
  }, [userName]);

  useEffect(() => {
    const filterProjects = async () => {
      let filteredProjects = searchTerm
        ? projects.filter(
            (project) =>
              project.project_name &&
              project.project_name
                .toLowerCase()
                .includes(searchTerm.toLowerCase())
          )
        : projects;

      // Further filter by status if any filters are selected
      if (statusFilters.length > 0) {
        filteredProjects = filteredProjects.filter((project) => {
          if (
            statusFilters.includes("Idle") &&
            project.status.includes("Idle")
          ) {
            return true;
          }
          if (
            statusFilters.includes("Completed") &&
            project.status.includes("Completed")
          ) {
            return true;
          }
          if (
            statusFilters.includes("Terminated") &&
            (project.status.includes("Terminated") ||
              project.status.includes("Failed"))
          ) {
            return true;
          }
          // Treat any other status as "Running"
          if (
            statusFilters.includes("Running") &&
            !project.status.includes("Idle") &&
            !project.status.includes("Completed") &&
            !project.status.includes("Terminated") &&
            !project.status.includes("Failed")
          ) {
            return true;
          }
          return false;
        });
      }

      setFilteredProjects(filteredProjects);
    };
    filterProjects();
  }, [searchTerm, projects, statusFilters]);

  const openProject = (id: string) => {
    window.location.href = `/project/${id}`;
  };

  useEffect(() => {
    document.title = `Projects | blit.ai`;
  });

  // Warm up lambda functions and instances
  useEffect(() => {
    api.post("/step2stl", { warm_up: 1 }).catch(() => {});
    api.post("/generate_mesh", { warm_up: 1 }).catch(() => {});
    api.post("/classify_mesh", { warm_up: 1 }).catch(() => {});
    api.post("/run_simulation", { warm_up: 1 }).catch(() => {});
  }, []);

  function getStatusColor(status: string, tailwind: boolean = false) {
    if (status.includes("Idle")) {
      return tailwind ? "gray" : "#344054";
    } else if (status.includes("Completed")) {
      return tailwind ? "success" : "#027A48";
    } else if (status.includes("Terminated") || status.includes("Failed")) {
      return tailwind ? "error" : "#B42318";
    } else {
      return tailwind ? "warning" : "#B54708";
    }
  }

  // CHANGE OF ROUTE FOR MOBILE
  const [isWideScreen, setIsWideScreen] = useState<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      setIsWideScreen(window.innerWidth >= 1000);
    };

    handleResize(); // Initial check on component mount

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <>
      <div className="bg-gray-100 bg-gray-500 bg-success-100 bg-success-500 bg-error-100 bg-error-500 bg-warning-100 bg-warning-500"></div>
      <div className="flex w-full h-full overflow-hidden">
        <div
          className={
            openMobileMenu
              ? "fixed min-[1200px]:relative translate-x-0 min-[1200px]:translate-x-0 z-40 transition-all duration-300"
              : "fixed min-[1200px]:relative -translate-x-full min-[1200px]:translate-x-0 z-40 transition-all duration-300"
          }
        >
          {/* SIDEBAR */}
          <aside
            className="font-inter w-80 min-h-screen overflow-y-auto touch-auto border-r-2 border-gray-200 z-30 relative"
            aria-label="Sidebar"
          >
            <div className="overflow-y-auto bg-white flex flex-col h-screen">
              {/* LOGO */}
              <div className="pt-[27px]">
                <svg
                  className="mx-auto"
                  width="90"
                  height="37"
                  viewBox="0 0 166 69"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M9.536 67.104C11.2427 67.7867 13.056 68.128 14.976 68.128C16.8533 68.128 18.688 67.7013 20.48 66.848C22.272 65.9947 23.872 64.8 25.28 63.264C26.7307 61.6853 27.8827 59.808 28.736 57.632C29.5893 55.456 30.016 53.0453 30.016 50.4C30.016 46.7733 29.3333 43.7013 27.968 41.184C26.6027 38.624 24.7893 36.6827 22.528 35.36C20.3093 33.9947 17.92 33.312 15.36 33.312C13.0987 33.312 11.136 33.7813 9.472 34.72C7.85067 35.616 6.61334 36.5547 5.76 37.536V20H0V67.36H5.376V64.608C6.48533 65.5467 7.872 66.3787 9.536 67.104ZM18.944 61.472C17.3653 62.496 15.5307 63.008 13.44 63.008C11.9467 63.008 10.5387 62.7733 9.216 62.304C7.89333 61.8347 6.74133 61.216 5.76 60.448V42.656C6.528 41.5893 7.63734 40.608 9.088 39.712C10.5813 38.7733 12.2453 38.304 14.08 38.304C15.9147 38.304 17.5787 38.7947 19.072 39.776C20.608 40.7573 21.824 42.1653 22.72 44C23.6587 45.8347 24.128 48.032 24.128 50.592C24.128 53.0667 23.6587 55.2427 22.72 57.12C21.824 58.9973 20.5653 60.448 18.944 61.472ZM42.8 67.04C44.3787 67.7653 46.1493 68.128 48.112 68.128C49.4773 68.128 50.7147 68 51.824 67.744C52.976 67.488 53.936 67.1893 54.704 66.848L53.296 62.176C52.7413 62.432 52.0587 62.6667 51.248 62.88C50.48 63.0507 49.6907 63.136 48.88 63.136C47.1733 63.136 45.8293 62.5813 44.848 61.472C43.9093 60.3627 43.44 58.656 43.44 56.352V20H37.68V56.928C37.68 59.5733 38.128 61.728 39.024 63.392C39.9627 65.056 41.2213 66.272 42.8 67.04ZM60.125 34.08V67.36H65.885V34.08H60.125ZM80.157 64.992C82.0343 67.0827 84.573 68.128 87.773 68.128C89.3517 68.128 90.8663 67.872 92.317 67.36C93.7677 66.8907 94.9197 66.4 95.773 65.888L94.173 61.28C93.3623 61.7493 92.4663 62.1547 91.485 62.496C90.5463 62.8373 89.5437 63.008 88.477 63.008C87.0263 63.008 85.7677 62.5173 84.701 61.536C83.677 60.5547 83.165 58.8267 83.165 56.352V40.288H92.381V35.296H83.165V24.8H78.749L77.533 35.296H71.645V40.288H77.405V55.904C77.405 59.8293 78.3223 62.8587 80.157 64.992ZM103.035 66.848C103.888 67.7013 104.891 68.128 106.043 68.128C107.28 68.128 108.304 67.744 109.115 66.976C109.925 66.1653 110.331 65.12 110.331 63.84C110.331 62.688 109.882 61.6853 108.987 60.832C108.133 59.9787 107.152 59.552 106.043 59.552C104.72 59.552 103.674 59.936 102.907 60.704C102.139 61.472 101.755 62.5173 101.755 63.84C101.755 64.992 102.181 65.9947 103.035 66.848ZM124.309 66.016C126.57 67.424 129.088 68.128 131.861 68.128C134.464 68.128 136.597 67.5733 138.261 66.464C139.968 65.312 141.312 64.0533 142.293 62.688C143.146 66.016 145.621 67.68 149.717 67.68L150.933 63.2C149.994 63.2 149.12 62.9653 148.309 62.496C147.541 61.984 147.157 60.9173 147.157 59.296V34.08H141.909V36.768C140.757 35.7867 139.392 34.976 137.813 34.336C136.277 33.6533 134.549 33.312 132.629 33.312C129.557 33.312 126.826 34.1013 124.437 35.68C122.09 37.216 120.234 39.3067 118.869 41.952C117.546 44.5973 116.885 47.584 116.885 50.912C116.885 54.4107 117.546 57.4613 118.869 60.064C120.234 62.624 122.048 64.608 124.309 66.016ZM137.749 61.856C136.298 62.624 134.762 63.008 133.141 63.008C131.178 63.008 129.408 62.496 127.829 61.472C126.25 60.4053 125.013 58.9547 124.117 57.12C123.221 55.2427 122.773 53.1093 122.773 50.72C122.773 48.2453 123.221 46.0907 124.117 44.256C125.013 42.3787 126.229 40.928 127.765 39.904C129.344 38.8373 131.157 38.304 133.205 38.304C134.741 38.304 136.192 38.56 137.557 39.072C138.965 39.5413 140.245 40.1813 141.397 40.992V58.848C140.416 60.0427 139.2 61.0453 137.749 61.856ZM158.625 27.168C159.436 27.9787 160.396 28.384 161.505 28.384C162.742 28.384 163.724 28.0213 164.449 27.296C165.174 26.528 165.537 25.5467 165.537 24.352C165.537 23.2427 165.132 22.304 164.321 21.536C163.553 20.7253 162.614 20.32 161.505 20.32C160.268 20.32 159.286 20.6827 158.561 21.408C157.836 22.1333 157.473 23.1147 157.473 24.352C157.473 25.4187 157.857 26.3573 158.625 27.168ZM158.625 34.08V67.36H164.385V34.08H158.625Z"
                    fill="url(#paint0_radial_15_2)"
                  />
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M50.2536 3.13829C58.2895 -0.566264 67.6983 -0.566523 75.7351 3.13996L72.3634 7.15819C66.3789 4.75576 59.6101 4.75562 53.6256 7.15691L50.2536 3.13829ZM47.5354 4.56599C45.875 5.55101 44.2935 6.70901 42.8185 8.03999C42.3919 8.42498 42.3835 9.07686 42.7961 9.47624L44.9896 11.5994C45.383 11.9806 46.0159 11.9887 46.4246 11.6231C47.7938 10.3994 49.2721 9.35489 50.8277 8.48958L47.5354 4.56599ZM75.1611 8.49125L78.4531 4.56803C80.1121 5.55256 81.6924 6.70987 83.1664 8.03999C83.5931 8.42498 83.6014 9.07686 83.1895 9.47624L80.996 11.5994C80.6026 11.98 79.9697 11.9887 79.561 11.6231C78.1927 10.4002 76.7154 9.3562 75.1611 8.49125ZM58.8925 24.36C58.8925 22.1506 60.7279 20.36 62.9925 20.36C65.2571 20.36 67.0925 22.1506 67.0925 24.36C67.0925 26.5694 65.2571 28.36 62.9925 28.36C60.7279 28.36 58.8925 26.5694 58.8925 24.36ZM64.4925 10.4156C68.6282 10.7213 72.6825 12.294 75.976 15.1356C76.4174 15.5162 76.4321 16.1787 76.0119 16.5825L73.8056 18.7069C73.4212 19.0775 72.8024 19.1019 72.393 18.7569C70.1093 16.8305 67.3377 15.7223 64.4925 15.4346V10.4156ZM61.4925 10.4156C57.3551 10.7217 53.3004 12.2957 50.0089 15.1356C49.5669 15.5169 49.5528 16.1787 49.9724 16.5825L52.1787 18.7069C52.5631 19.0769 53.1819 19.1019 53.5913 18.7569C55.8781 16.8283 58.6496 15.7215 61.4925 15.4344V10.4156Z"
                    fill="url(#paint1_radial_15_2)"
                  />
                  <defs>
                    <radialGradient
                      id="paint0_radial_15_2"
                      cx="0"
                      cy="0"
                      r="1"
                      gradientUnits="userSpaceOnUse"
                      gradientTransform="translate(-3.49999 69.4575) rotate(-11.8452) scale(174.721 157.646)"
                    >
                      <stop stopColor="#7000FF" />
                      <stop offset="1" stopColor="#FF0094" />
                    </radialGradient>
                    <radialGradient
                      id="paint1_radial_15_2"
                      cx="0"
                      cy="0"
                      r="1"
                      gradientUnits="userSpaceOnUse"
                      gradientTransform="translate(41.6256 29.1334) rotate(-26.2272) scale(47.2138 84.0633)"
                    >
                      <stop stopColor="#7000FF" />
                      <stop offset="1" stopColor="#FF0094" />
                    </radialGradient>
                  </defs>
                </svg>
              </div>

              <div className="flex flex-col justify-between h-full">
                {/* LINKS LIST */}
                <ul className="pt-9 px-4 space-y-1">
                  {/* LINK */}
                  <li>
                    <a
                      href="#abc"
                      className="hover:bg-gray-50 active:bg-gray-100 px-3 py-2 flex items-center justify-between rounded-md"
                    >
                      <span className="flex items-center">
                        <div className="w-6 h-6">
                          <svg
                            width="20"
                            height="21"
                            viewBox="0 0 20 21"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-auto"
                          >
                            <path
                              d="M6 16H14M9.0177 1.76403L2.23539 7.03916C1.78202 7.39178 1.55534 7.56809 1.39203 7.78889C1.24737 7.98447 1.1396 8.20481 1.07403 8.43908C1 8.70355 1 8.99073 1 9.56508V16.8C1 17.9201 1 18.4802 1.21799 18.908C1.40973 19.2843 1.71569 19.5903 2.09202 19.782C2.51984 20 3.07989 20 4.2 20H15.8C16.9201 20 17.4802 20 17.908 19.782C18.2843 19.5903 18.5903 19.2843 18.782 18.908C19 18.4802 19 17.9201 19 16.8V9.56508C19 8.99073 19 8.70355 18.926 8.43908C18.8604 8.20481 18.7526 7.98447 18.608 7.78889C18.4447 7.56809 18.218 7.39178 17.7646 7.03916L10.9823 1.76403C10.631 1.49078 10.4553 1.35415 10.2613 1.30163C10.0902 1.25529 9.9098 1.25529 9.73865 1.30163C9.54468 1.35415 9.36902 1.49078 9.0177 1.76403Z"
                              stroke="#667085"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </div>

                        <span className="ml-3 text-md font-semibold text-gray-700">
                          Home
                        </span>
                      </span>
                    </a>
                  </li>

                  {/* LINK */}
                  <li>
                    <a
                      href="overview"
                      className="hover:bg-gray-50 active:bg-gray-100 px-3 py-2 flex items-center justify-between rounded-md"
                    >
                      <span className="flex items-center">
                        <div className="w-6 h-6">
                          <svg
                            width="20"
                            height="20"
                            viewBox="0 0 20 20"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-auto"
                          >
                            <path
                              d="M6 13V15M10 9V15M14 5V15M5.8 19H14.2C15.8802 19 16.7202 19 17.362 18.673C17.9265 18.3854 18.3854 17.9265 18.673 17.362C19 16.7202 19 15.8802 19 14.2V5.8C19 4.11984 19 3.27976 18.673 2.63803C18.3854 2.07354 17.9265 1.6146 17.362 1.32698C16.7202 1 15.8802 1 14.2 1H5.8C4.11984 1 3.27976 1 2.63803 1.32698C2.07354 1.6146 1.6146 2.07354 1.32698 2.63803C1 3.27976 1 4.11984 1 5.8V14.2C1 15.8802 1 16.7202 1.32698 17.362C1.6146 17.9265 2.07354 18.3854 2.63803 18.673C3.27976 19 4.11984 19 5.8 19Z"
                              stroke="#667085"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </div>

                        <span className="ml-3 text-md font-semibold text-gray-700">
                          Overview
                        </span>
                      </span>
                    </a>
                  </li>

                  {/* LINK */}
                  <li>
                    <a
                      href="projects"
                      className="bg-gray-50 hover:bg-gray-100 active:bg-gray-200 px-3 py-2 flex items-center justify-between rounded-md"
                    >
                      <span className="flex items-center">
                        <div className="w-6 h-6">
                          <svg
                            width="22"
                            height="22"
                            viewBox="0 0 22 22"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-auto"
                          >
                            <path
                              d="M1 11L10.6422 15.8211C10.7734 15.8867 10.839 15.9195 10.9078 15.9324C10.9687 15.9438 11.0313 15.9438 11.0922 15.9324C11.161 15.9195 11.2266 15.8867 11.3578 15.8211L21 11M1 16L10.6422 20.8211C10.7734 20.8867 10.839 20.9195 10.9078 20.9324C10.9687 20.9438 11.0313 20.9438 11.0922 20.9324C11.161 20.9195 11.2266 20.8867 11.3578 20.8211L21 16M1 6L10.6422 1.17889C10.7734 1.1133 10.839 1.0805 10.9078 1.0676C10.9687 1.05616 11.0313 1.05616 11.0922 1.0676C11.161 1.0805 11.2266 1.1133 11.3578 1.17889L21 6L11.3578 10.8211C11.2266 10.8867 11.161 10.9195 11.0922 10.9324C11.0313 10.9438 10.9687 10.9438 10.9078 10.9324C10.839 10.9195 10.7734 10.8867 10.6422 10.8211L1 6Z"
                              stroke="black"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </div>

                        <span className="ml-3 text-md font-semibold text-gray-900">
                          Projects
                        </span>
                      </span>

                      <div className=" w-6 h-6 flex items-center justify-center rounded-full bg-gray-100 text-gray-700 text-xs font-medium">
                        {isQuerying ? "-" : projects.length}
                      </div>
                    </a>
                  </li>
                </ul>

                {/* FOOTER */}
                <footer className="flex flex-col px-4 pb-8 space-y-6">
                  <ul className="space-y-1">
                    {/* LINK */}
                    <li>
                      <a
                        href="#abc"
                        className="hover:bg-gray-50 active:bg-gray-100 px-3 py-2 flex items-center justify-between rounded-md"
                      >
                        <span className="flex items-center">
                          <div className="w-6 h-6">
                            <svg
                              width="20"
                              height="22"
                              viewBox="0 0 20 22"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              className="mx-auto"
                            >
                              <path
                                d="M18.7778 21C18.7778 19.4494 18.7778 18.6741 18.5864 18.0432C18.1555 16.6227 17.0439 15.5112 15.6235 15.0803C14.9926 14.8889 14.2173 14.8889 12.6667 14.8889H7.11112C5.56049 14.8889 4.78517 14.8889 4.15429 15.0803C2.73384 15.5112 1.62227 16.6227 1.19138 18.0432C1 18.6741 1 19.4494 1 21M14.8889 6C14.8889 8.76142 12.6503 11 9.88889 11C7.12747 11 4.88889 8.76142 4.88889 6C4.88889 3.23858 7.12747 1 9.88889 1C12.6503 1 14.8889 3.23858 14.8889 6Z"
                                stroke="#667085"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />
                            </svg>
                          </div>

                          <span className="ml-3 text-md font-semibold text-gray-700">
                            Account
                          </span>
                        </span>
                      </a>
                    </li>

                    {/* LINK */}
                    <li>
                      <a
                        href="#abc"
                        className="hover:bg-gray-50 active:bg-gray-100 px-3 py-2 flex items-center justify-between rounded-md"
                      >
                        <span className="flex items-center">
                          <div className="w-6 h-6">
                            <svg
                              width="22"
                              height="22"
                              viewBox="0 0 22 22"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              className="mx-auto"
                            >
                              <path
                                d="M8.13626 8.13628L3.92893 3.92896M3.92893 18.0711L8.16797 13.8321M13.8611 13.8638L18.0684 18.0711M18.0684 3.92896L13.8287 8.16862M21 11C21 16.5228 16.5228 21 11 21C5.47715 21 1 16.5228 1 11C1 5.47715 5.47715 1 11 1C16.5228 1 21 5.47715 21 11ZM15 11C15 13.2091 13.2091 15 11 15C8.79086 15 7 13.2091 7 11C7 8.79086 8.79086 7 11 7C13.2091 7 15 8.79086 15 11Z"
                                stroke="#667085"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              />
                            </svg>
                          </div>

                          <span className="ml-3 text-md font-semibold text-gray-700">
                            Support
                          </span>
                        </span>
                      </a>
                    </li>
                  </ul>
                  <div className="pt-6 border-t border-gray-200 pl-2 pr-2.5">
                    <div className="flex justify-between">
                      <div className="flex flex-col text-sm">
                        <h6 className="font-semibold text-gray-700">
                          {userPlan || "Unknown plan"}
                        </h6>
                        <h6 className="text-gray-600">{email}</h6>
                      </div>
                      <button
                        className="w-5 h-5"
                        onClick={() => {
                          setIsLoading(true);
                          Auth.signOut().then(() => {
                            localStorage.clear();
                            setIsLoading(false);
                            navigate("/", { replace: true });
                          });
                        }}
                      >
                        {isLoading ? (
                          <svg
                            aria-hidden="true"
                            className="w-5 h-5 animate-spin fill-[#7f56d9] text-white"
                            viewBox="0 0 100 101"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                              fill="currentColor"
                            />
                            <path
                              d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                              fill="currentFill"
                            />
                          </svg>
                        ) : (
                          <>
                            <span
                              data-tooltip-id="logout-tooltip"
                              data-tooltip-content="Log out"
                            >
                              <svg
                                className="w-4 h-4"
                                width="18"
                                height="18"
                                viewBox="0 0 18 18"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                                <path
                                  d="M12.3333 13.1667L16.5 9M16.5 9L12.3333 4.83333M16.5 9H6.5M6.5 1.5H5.5C4.09987 1.5 3.3998 1.5 2.86502 1.77248C2.39462 2.01217 2.01217 2.39462 1.77248 2.86502C1.5 3.3998 1.5 4.09987 1.5 5.5V12.5C1.5 13.9001 1.5 14.6002 1.77248 15.135C2.01217 15.6054 2.39462 15.9878 2.86502 16.2275C3.3998 16.5 4.09987 16.5 5.5 16.5H6.5"
                                  stroke="#667085"
                                  strokeWidth="1.66667"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                            </span>
                            <Tooltip id="logout-tooltip" />
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </footer>
              </div>
            </div>
          </aside>

          <div
            style={{ display: openMobileMenu ? "flex" : "none" }}
            className="z-40 absolute top-0 -right-[30px] bg-white border-r-white border-2 border-[#EAECF0] w-8 h-8 -scale-100 flex min-[1586px]:hidden items-center justify-center rounded-tl-md rounded-bl-md"
            onClick={() => setOpenMobileMenu(false)}
          >
            <MyIcon name="right-arrow" color="#667085" />
          </div>

          <div
            style={{ display: openMobileMenu ? "block" : "none" }}
            className="absolute inset-0 w-[800vw] h-screen bg-black opacity-40"
            onClick={() => setOpenMobileMenu(false)}
          ></div>
        </div>

        <div className="bg-gray-25 w-full flex flex-col min-h-full">
          {/* HEADER */}
          <div className="py-8">
            <div className="px-4 md:px-8 flex flex-col space-y-5">
              <div className="flex items-center justify-start gap-4">
                <div
                  className="min-[1200px]:hidden flex items-center justify-center cursor-pointer"
                  onClick={() => setOpenMobileMenu(true)}
                >
                  <MyIcon name="menu" />
                </div>
                {/* BREADCRUM */}
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 flex items-center justify-center">
                    <svg
                      width="20"
                      height="21"
                      viewBox="0 0 20 21"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="mx-auto"
                    >
                      <path
                        d="M6 16H14M9.0177 1.76403L2.23539 7.03916C1.78202 7.39178 1.55534 7.56809 1.39203 7.78889C1.24737 7.98447 1.1396 8.20481 1.07403 8.43908C1 8.70355 1 8.99073 1 9.56508V16.8C1 17.9201 1 18.4802 1.21799 18.908C1.40973 19.2843 1.71569 19.5903 2.09202 19.782C2.51984 20 3.07989 20 4.2 20H15.8C16.9201 20 17.4802 20 17.908 19.782C18.2843 19.5903 18.5903 19.2843 18.782 18.908C19 18.4802 19 17.9201 19 16.8V9.56508C19 8.99073 19 8.70355 18.926 8.43908C18.8604 8.20481 18.7526 7.98447 18.608 7.78889C18.4447 7.56809 18.218 7.39178 17.7646 7.03916L10.9823 1.76403C10.631 1.49078 10.4553 1.35415 10.2613 1.30163C10.0902 1.25529 9.9098 1.25529 9.73865 1.30163C9.54468 1.35415 9.36902 1.49078 9.0177 1.76403Z"
                        stroke="#667085"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>

                  <div className="w-4 h-4 flex items-center justify-center">
                    <svg
                      width="6"
                      height="10"
                      viewBox="0 0 6 10"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="mx-auto"
                    >
                      <path
                        d="M1 9L5 5L1 1"
                        stroke="#D0D5DD"
                        strokeWidth="1.33333"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>

                  <span className="my-auto px-2 py-1 flex text-sm items-center bg-grayIron-100 justify-center rounded focus:outline-none text-gray-600 font-semibold">
                    Projects
                  </span>
                </div>
              </div>

              {/* CONTENT */}
              <div className="flex flex-col space-y-1">
                <h4 className=" text-tsm text-gray-900 font-semibold">
                  Projects
                </h4>
                <h6 className=" text-md text-gray-600">
                  View your simulation projects.
                </h6>
              </div>

              <div className="border-b border-gray-200"></div>
            </div>
          </div>

          {/* SECTION */}
          <div className="px-4 md:px-8 pb-6 flex flex-col h-full space-y-6">
            {/* CONTENT */}
            <div className="flex items-center gap-3 justify-between">
              <div className="w-full max-w-[400px] h-11 relative bg-white border border-gray-300 shadow-xs rounded-lg">
                <div className="w-5 h-5 absolute top-[11px] left-[14px] pointer-events-none">
                  <svg
                    width="18"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M19 19L14.65 14.65M17 9C17 13.4183 13.4183 17 9 17C4.58172 17 1 13.4183 1 9C1 4.58172 4.58172 1 9 1C13.4183 1 17 4.58172 17 9Z"
                      stroke="#667085"
                      strokeWidth="1.66667"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <input
                  className="w-full h-full rounded-lg pl-[42px] pr-[14px] py-2.5 text-md text-gray-600 placeholder:text-gray-500 focus:ring-gray-300 focus:border-gray-300 focus-visible:ring-gray-300 focus-visible:outline-0"
                  placeholder="Search for a project"
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onWaiting={(e) => setSearchTerm("")}
                />
              </div>
              <div className="relative inline-block text-left">
                <button
                  className="w-[103px] h-10 bg-white border border-gray-300 shadow-xs rounded-lg flex items-center justify-center hover:bg-gray-50 active:bg-gray-200"
                  onClick={() => setFiltersVisible(!filtersVisible)}
                >
                  <span className="w-5 h-5 flex items-center justify-center">
                    <svg
                      width="18"
                      height="12"
                      viewBox="0 0 18 12"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="mx-auto"
                    >
                      <path
                        d="M4 6H14M1.5 1H16.5M6.5 11H11.5"
                        stroke="#344054"
                        strokeWidth="1.66667"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                  <span className=" text-sm text-gray-700 font-semibold ml-2">
                    Filters
                  </span>
                </button>
                {filtersVisible && (
                  <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                    <div
                      className="py-1"
                      role="menu"
                      aria-orientation="vertical"
                      aria-labelledby="options-menu"
                    >
                      {["Idle", "Running", "Completed", "Terminated"].map(
                        (status) => (
                          <label className="cursor-pointer">
                            <div
                              key={status}
                              className="px-4 py-1 flex items-center hover:bg-gray-50 active:bg-gray-100"
                            >
                              <input
                                type="checkbox"
                                className={`mr-3 ${
                                  status === "Idle"
                                    ? "accent-gray-500"
                                    : status === "Running"
                                    ? "accent-warning-600"
                                    : status === "Completed"
                                    ? "accent-success-600"
                                    : "accent-error-600"
                                }`}
                                checked={statusFilters.includes(status)}
                                onChange={() => toggleFilter(status)}
                              />
                              {status}
                            </div>
                          </label>
                        )
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* TABLE */}
            <div className="h-full">
              {/* CARD HEADER */}
              <div className="bg-white px-6 py-5 rounded-t-xl shadow-sm border border-b-0 border-gray-200">
                <div className="flex items-center justify-between">
                  <h5 className=" text-lg text-gray-900 font-semibold">
                    All projects
                  </h5>
                  <button
                    className="w-[142px] h-10 bg-primary-600 hover:bg-primary-700 active:bg-primary-800 hover:transition duration-150 shadow-sm hover:shadow-primary-600/50 rounded-lg flex items-center justify-center"
                    onClick={createNewProject}
                  >
                    <span className="w-5 h-5 flex items-center justify-center">
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 14 14"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="mx-auto"
                      >
                        <path
                          d="M7.00002 1.16667V12.8333M1.16669 7H12.8334"
                          stroke="white"
                          strokeWidth="1.66667"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                    <span className="text-sm text-white font-semibold ml-2">
                      New project
                    </span>
                  </button>
                </div>
              </div>

              <div ref={tableRef} style={{ minHeight: "100%" }}>
                <TableContainer className="bg-white border border-gray-200 shadow-sm rounded-xl rounded-t-none">
                  <Table
                    style={{
                      minHeight: "100%",
                    }}
                  >
                    <TableHead
                      component="div"
                      ref={tableHeadRef}
                      className="bg-gray-50 border-b border-gray-200"
                    >
                      <TableRow className="cursor-default">
                        <TableCell
                          className="cursor-auto"
                          width={"17%"}
                          style={{
                            padding: "4px 23px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>
                            Project name
                          </div>
                        </TableCell>
                        <TableCell
                          className="cursor-auto"
                          width={"12%"}
                          style={{
                            padding: "4px 16px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>Type</div>
                        </TableCell>
                        <TableCell
                          className="cursor-auto"
                          width={"17%"}
                          style={{
                            padding: "4px 16px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>
                            Date created
                          </div>
                        </TableCell>
                        <TableCell
                          className="cursor-auto"
                          width={"12%"}
                          style={{
                            padding: "4px 16px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>
                            Recent activity
                          </div>
                        </TableCell>
                        <TableCell
                          className="cursor-auto"
                          width={"12%"}
                          style={{
                            padding: "4px 16px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>
                            Status
                          </div>
                        </TableCell>
                        <TableCell
                          className="cursor-auto"
                          width={"12%"}
                          style={{
                            padding: "4px 28px",
                            fontSize: "13px",
                            fontFamily: "Inter",
                            fontWeight: "600",
                            height: "44px",
                            color: "#475467",
                          }}
                        >
                          <div style={{ inlineSize: "max-content" }}>
                            Actions
                          </div>
                        </TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody
                      style={{
                        height: "100%",
                      }}
                    >
                      {isQuerying ? (
                        <TableRow className="cursor-default">
                          <TableCell
                            style={{
                              padding: "4px 24px",
                              fontSize: "0.875rem",
                              fontFamily: "Inter",
                              height: "44px",
                              color: "#475467",
                            }}
                            colSpan={6}
                          >
                            <svg
                              aria-hidden="true"
                              className="w-6 h-6 ml-8 animate-spin fill-[#667085] text-white"
                              viewBox="0 0 100 101"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                fill="currentColor"
                              />
                              <path
                                d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                fill="currentFill"
                              />
                            </svg>
                          </TableCell>
                        </TableRow>
                      ) : !isQuerying && filteredProjects.length === 0 ? (
                        <TableRow>
                          <TableCell
                            className="cursor-auto"
                            style={{
                              padding: "4px 24px",
                              fontSize: "0.875rem",
                              fontFamily: "Inter",
                              height: "44px",
                              color: "#475467",
                            }}
                            colSpan={6}
                          >
                            <div className="flex items-center justify-center space-x-1">
                              <span className="text-gray-600">
                                No projects found.
                              </span>
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : null}
                      {filteredProjects
                        .slice(
                          (page - 1) * tableRows,
                          (page - 1) * tableRows + tableRows
                        )
                        .map((project, index) => {
                          return (
                            <TableRow
                              id={"table-row"}
                              key={project.id}
                              onClick={() => openProject(project.id)}
                              className="bg-white hover:bg-gray-50 active:bg-gray-100 border-b border-[#e0e0e0] cursor-pointer"
                            >
                              <TableCell
                                style={{
                                  padding: "4px 24px",
                                  fontSize: "0.875rem",
                                  fontFamily: "Inter",
                                  height: "44px",
                                  color: "#475467",
                                  borderBottom: "transparent",
                                }}
                              >
                                <div
                                  style={{
                                    inlineSize: isWideScreen
                                      ? ""
                                      : "max-content",
                                  }}
                                >
                                  <span
                                    style={{
                                      fontFamily: "Inter",
                                      fontWeight: "500",
                                      color: "#101828",
                                    }}
                                  >
                                    {project.project_name}
                                  </span>
                                  <br />
                                  {project.frequency_range}
                                </div>
                              </TableCell>
                              <TableCell
                                style={{
                                  fontSize: "0.875rem",
                                  fontFamily: "Inter",
                                  height: "44px",
                                  color: "#475467",
                                  borderBottom: "transparent",
                                }}
                              >
                                <div
                                  style={{
                                    inlineSize: isWideScreen
                                      ? ""
                                      : "max-content",
                                  }}
                                >
                                  {project.type}
                                </div>
                              </TableCell>
                              <TableCell
                                style={{
                                  fontSize: "0.875rem",
                                  fontFamily: "Inter",
                                  height: "44px",
                                  color: "#475467",
                                  borderBottom: "transparent",
                                }}
                              >
                                <div
                                  style={{
                                    inlineSize: isWideScreen
                                      ? ""
                                      : "max-content",
                                  }}
                                >
                                  {project.createdAt
                                    ? new Date(
                                        project.createdAt
                                      ).toLocaleString("en-US", {
                                        year: "numeric",
                                        month: "short",
                                        day: "numeric",
                                        hour: "numeric",
                                        minute: "numeric",
                                      })
                                    : "-"}
                                </div>
                              </TableCell>
                              <TableCell
                                style={{
                                  fontSize: "0.875rem",
                                  fontFamily: "Inter",
                                  height: "44px",
                                  color: "#475467",
                                  borderBottom: "transparent",
                                }}
                              >
                                <div
                                  style={{
                                    inlineSize: isWideScreen
                                      ? ""
                                      : "max-content",
                                  }}
                                >
                                  {moment(project.lastModified).fromNow()}
                                </div>
                              </TableCell>
                              <TableCell
                                style={{
                                  fontSize: "0.875rem",
                                  fontFamily: "Inter",
                                  height: "44px",
                                  color: getStatusColor(project.status, false),
                                  borderBottom: "transparent",
                                }}
                              >
                                <div className="flex items-center">
                                  <div
                                    className={`flex items-center bg-${getStatusColor(
                                      project.status,
                                      true
                                    )}-100 py-0.5 pr-2 pl-1.5 mix-blend-multiply rounded-2xl`}
                                  >
                                    <div
                                      className={`w-1.5 h-1.5 rounded-full bg-${getStatusColor(
                                        project.status,
                                        true
                                      )}-500`}
                                    ></div>
                                    <div className="text-xs font-medium ml-1.5">
                                      {project.status.includes("Idle") ||
                                      project.status.includes("Terminated") ||
                                      project.status.includes("Failed")
                                        ? project.status
                                            .replace("<b>", "")
                                            .replace("</b>", "")
                                            .replace("<code>", "")
                                            .replace("</code>", "")
                                        : project.percentage === 100
                                        ? "Completed"
                                        : "Running (" +
                                          Math.round(project.percentage) +
                                          "%)"}
                                    </div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell
                                style={{
                                  display: "flex",
                                  borderBottom: "transparent",
                                }}
                              >
                                <button className="w-10 h-10 flex items-center justify-center">
                                  <svg
                                    width="20"
                                    height="18"
                                    viewBox="0 0 20 18"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      d="M6.66669 13.1667L10 16.5M10 16.5L13.3334 13.1667M10 16.5V9M16.6667 12.9524C17.6846 12.1117 18.3334 10.8399 18.3334 9.41667C18.3334 6.88536 16.2813 4.83333 13.75 4.83333C13.5679 4.83333 13.3976 4.73833 13.3051 4.58145C12.2184 2.73736 10.212 1.5 7.91669 1.5C4.46491 1.5 1.66669 4.29822 1.66669 7.75C1.66669 9.47175 2.36289 11.0309 3.48914 12.1613"
                                      stroke="#475467"
                                      strokeWidth="1.66667"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                    />
                                  </svg>
                                </button>

                                <button
                                  className="w-10 h-10 flex items-center justify-center"
                                  onClick={(e) => {
                                    setProjectIdToDelete(project.id);
                                    setProjectNameToDelete(
                                      project.project_name
                                    );
                                    setDeleteProjectModalVisible(true);
                                    e.stopPropagation();
                                  }}
                                >
                                  <span
                                    data-tooltip-id="delete-tooltip"
                                    data-tooltip-content="Delete project"
                                  >
                                    <svg
                                      width="18"
                                      height="20"
                                      viewBox="0 0 18 20"
                                      fill="none"
                                      xmlns="http://www.w3.org/2000/svg"
                                    >
                                      <path
                                        d="M12.3333 5V4.33333C12.3333 3.39991 12.3333 2.9332 12.1517 2.57668C11.9919 2.26308 11.7369 2.00811 11.4233 1.84832C11.0668 1.66667 10.6001 1.66667 9.66667 1.66667H8.33333C7.39991 1.66667 6.9332 1.66667 6.57668 1.84832C6.26308 2.00811 6.00811 2.26308 5.84832 2.57668C5.66667 2.9332 5.66667 3.39991 5.66667 4.33333V5M7.33333 9.58333V13.75M10.6667 9.58333V13.75M1.5 5H16.5M14.8333 5V14.3333C14.8333 15.7335 14.8333 16.4335 14.5608 16.9683C14.3212 17.4387 13.9387 17.8212 13.4683 18.0609C12.9335 18.3333 12.2335 18.3333 10.8333 18.3333H7.16667C5.76654 18.3333 5.06647 18.3333 4.53169 18.0609C4.06129 17.8212 3.67883 17.4387 3.43915 16.9683C3.16667 16.4335 3.16667 15.7335 3.16667 14.3333V5"
                                        stroke="#D92D20"
                                        strokeWidth="1.66667"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                      />
                                    </svg>
                                  </span>
                                </button>
                                <Tooltip id="delete-tooltip" />
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </TableBody>
                    <TableRow
                      ref={tablePaginationRef}
                      component="div"
                      className="cursor-default"
                    >
                      <TableCell
                        className="cursor-default"
                        style={{ borderBottom: "none" }}
                        colSpan={6}
                      >
                        <Pagination
                          className="cursor-pointer"
                          count={Math.ceil(filteredProjects.length / tableRows)}
                          page={page}
                          onChange={(evt, page) => setPage(page)}
                        />
                      </TableCell>
                    </TableRow>
                  </Table>
                </TableContainer>
              </div>
              {/* TABLE CONTENT */}
              <NewProjectModal
                visible={newProjectModalVisible}
                setVisible={(value: boolean) =>
                  setNewProjectModalVisible(value)
                }
              />
              <DeleteProjectModal
                projectId={projectIdToDelete}
                projectName={projectNameToDelete}
                visible={deleteProjectModalVisible}
                setVisible={(value: boolean) =>
                  setDeleteProjectModalVisible(value)
                }
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Projects;
